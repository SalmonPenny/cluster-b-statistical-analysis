# Cluster B Stage 1 review
The archive includes the current curated raw observations, validation and comparison
outputs, source manifests, page index, reports, figures and Python utilities.
Review the reproduction section of cluster_b_analysis/reports/extraction_report.md.
The database builder and PDF indexer require the original local PDFs at the
manifest paths under cluster_b_analysis/papers/. Use the archived PDF page
index for review without the PDFs. The coverage utility uses the archived
validated results and comparability table and can run with Matplotlib and
NetworkX installed. The database builder and indexer require PyMuPDF.
